module.exports = {
  content: [
    "./pages/index.js",
    "./comps/Search.js"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
