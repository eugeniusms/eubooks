This is a [Next.js](https://nextjs.org/) project 

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
```

Open http://localhost:3000 with your browser to see the project

## Stacks

- Next.js
- TailwindCSS
- JavaScript, HTML, CSS
- GoogleAPI

## Github Repository

https://github.com/eugeniusms/eubooks
[Eubooks on Vercel](https://github.com/eugeniusms/eubooks)
