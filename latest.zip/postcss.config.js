module.exports = {
    plugins: ["tailwindcss"],
};